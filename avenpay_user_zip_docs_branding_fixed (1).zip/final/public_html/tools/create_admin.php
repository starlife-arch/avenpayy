<?php
// Create the first (or another) admin from the command line. Never reachable from the web.
//   php tools/create_admin.php --username=nova --email=you@example.com [--password=...]
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../database_config/db.php';
$o = getopt('', ['username:', 'email:', 'password::']);
if (empty($o['username']) || empty($o['email'])) { fwrite(STDERR, "Usage: php tools/create_admin.php --username=NAME --email=EMAIL [--password=PASS]\n"); exit(1); }
if (!filter_var($o['email'], FILTER_VALIDATE_EMAIL)) { fwrite(STDERR, "Invalid email address.\n"); exit(1); }
$pass = $o['password'] ?? null;
$generated = false;
if (!$pass) { $pass = rtrim(strtr(base64_encode(random_bytes(12)), '+/', 'Ab'), '='); $generated = true; }
if (strlen($pass) < 10) { fwrite(STDERR, "Password must be at least 10 characters.\n"); exit(1); }
$conn->query("CREATE TABLE IF NOT EXISTS `admins` (`id` INT AUTO_INCREMENT PRIMARY KEY, `username` VARCHAR(50) NOT NULL UNIQUE, `email` VARCHAR(100) NOT NULL UNIQUE, `password` VARCHAR(255) NOT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$hash = password_hash($pass, PASSWORD_DEFAULT);
$st = $conn->prepare("INSERT INTO admins (username, email, password) VALUES (?, ?, ?)");
$st->bind_param("sss", $o['username'], $o['email'], $hash);
$st->execute();
echo "Admin '{$o['username']}' created." . ($generated ? " Temporary password: $pass  (change it after first login)" : '') . "\n";
